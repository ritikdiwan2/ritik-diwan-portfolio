import { motion } from 'framer-motion';
export default function SectionHeading({ eyebrow, title, children, align = '' }) {
  return <motion.div className={`section-heading ${align}`} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .4 }} transition={{ duration: .45 }}>
    {eyebrow && <p className="eyebrow">{eyebrow}</p>}<h2>{title}<span className="scribble" /></h2>{children && <p>{children}</p>}
  </motion.div>;
}
