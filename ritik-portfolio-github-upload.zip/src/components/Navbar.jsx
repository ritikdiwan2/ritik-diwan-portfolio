import { useEffect, useState } from 'react';
import { Download, Menu, X } from './Icon';
import { navItems, links } from '../data';
export default function Navbar() { const [open, setOpen] = useState(false); const [active, setActive] = useState('home'); const [scrolled, setScrolled] = useState(false);
  useEffect(() => { const handler = () => { setScrolled(scrollY > 18); for (const [, id] of navItems) { const e = document.getElementById(id); if (e && e.getBoundingClientRect().top < 160 && e.getBoundingClientRect().bottom > 160) setActive(id); } }; addEventListener('scroll', handler); handler(); return () => removeEventListener('scroll', handler); }, []);
  const go = id => { document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' }); setOpen(false); };
  return <header className={`nav ${scrolled ? 'is-scrolled' : ''}`}><a className="brand" href="#home" onClick={() => go('home')}>Ritik Diwan<span /></a><nav className={open ? 'open' : ''}>{navItems.map(([label,id]) => <button className={active === id ? 'active' : ''} onClick={() => go(id)} key={id}>{label}</button>)}<a className="resume" href={links.resume} aria-label="Download resume">Resume <Download size={15}/></a></nav><button className="menu" onClick={() => setOpen(!open)} aria-label="Toggle navigation">{open ? <X/> : <Menu/>}</button></header>;
}
