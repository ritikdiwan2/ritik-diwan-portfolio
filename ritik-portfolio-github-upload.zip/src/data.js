import { Database, LayoutPanelTop, Sparkles, Terminal, Wrench } from './components/Icon';

// Replace only these placeholder values when you are ready to publish.
export const links = { email: 'your-email@example.com', github: '#', linkedin: '#', instagram: '#', resume: '#', projects: ['#', '#', '#', '#'] };
export const navItems = [['Home', 'home'], ['About', 'about'], ['Projects', 'projects'], ['Skills', 'skills'], ['Experience', 'experience'], ['Education', 'education'], ['Contact', 'contact']];
export const tech = ['JavaScript', 'React', 'Next.js', 'Node.js', 'Python', 'Java', 'SQL', 'Git', 'GitHub', 'Docker'];
export const skillGroups = [
  { title: 'Frontend', icon: LayoutPanelTop, color: 'blue', items: ['HTML', 'CSS', 'JavaScript', 'React', 'Next.js', 'Tailwind CSS'] },
  { title: 'Backend', icon: Terminal, color: 'green', items: ['Node.js', 'Express.js', 'Python', 'FastAPI', 'REST APIs'] },
  { title: 'Database', icon: Database, color: 'purple', items: ['MongoDB', 'PostgreSQL', 'MySQL'] },
  { title: 'Tools & Others', icon: Wrench, color: 'orange', items: ['Git', 'GitHub', 'VS Code', 'Docker', 'Postman', 'Linux'] },
  { title: 'AI / ML', icon: Sparkles, color: 'pink', items: ['Python', 'OpenAI API', 'LangChain', 'Prompt Engineering', 'NLP', 'AI API Integration'] }
];
export const projects = [
  { title: 'AI Job Hunter', kind: 'job', description: 'AI-powered job matching platform with resume analysis, skill matching and personalized job recommendations.', tech: ['React', 'Node.js', 'PostgreSQL', 'AI'] },
  { title: 'AI Expense Tracker', kind: 'expense', description: 'Expense tracking application with dashboards, budgeting and AI-powered financial insights.', tech: ['React', 'Node.js', 'PostgreSQL', 'AI'] },
  { title: 'Snake Game', kind: 'snake', description: 'Classic Snake game rebuilt with a modern interface, score tracking, levels and responsive controls.', tech: ['JavaScript', 'HTML', 'CSS'] },
  { title: 'Jarvis AI Assistant', kind: 'jarvis', description: 'Voice-enabled AI assistant built with Python and NLP concepts.', tech: ['Python', 'Flask', 'NLP'] }
];
export const timeline = [
  { title: 'Microsoft Azure AZ-900', meta: '5 Days Training · 2023', badge: 'Training' },
  { title: 'Web Development', meta: 'Personal Projects & Learning · 2024 — Present' },
  { title: 'Jarvis AI Project', meta: 'AI Project Competition · 2024' }
];
